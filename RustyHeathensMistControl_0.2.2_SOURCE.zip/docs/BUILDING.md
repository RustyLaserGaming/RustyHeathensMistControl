# Rebuild from source

Windows: install Valheim and BepInEx 5. From this source folder run:

    .\Build.ps1 -GamePath "C:\Program Files (x86)\Steam\steamapps\common\Valheim" -BepInExRoot "<active profile>\BepInEx"

The script compiles every src/*.cs file, embeds assets/Emblem.png and runs protocol, radius and gamma test executables. Output is build-output/RustyHeathensMistControl.dll. Nothing is auto-installed.

Uses Windows .NET Framework C# compiler and references from the installed game, including UnityEngine.UI and UnityEngine.ImageConversionModule. No game/reference binaries are distributed. The shipped DLL was compiled with Roslyn 4.8 in C# 5 mode against supplied game/BepInEx references. The PowerShell build script was reviewed but not executed here.

For another compiler, use a library target, embed assets/Emblem.png under resource name RHMC.Emblem.png, and use the assembly references listed in Build.ps1. Compile the standalone tests against your .NET runtime; their Unity/Harmony stubs are test-only and must never be included in the plugin DLL.
