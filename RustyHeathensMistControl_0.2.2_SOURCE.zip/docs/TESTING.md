# In-game acceptance checks — 0.2.0

Use a test world/profile first. Remove the standalone GammaMod and keep one Mist Control DLL. Install 0.2.0 on server and clients.

1. F8 opens a wooden panel using the inventory background, with the Rusty Heathens emblem. Verify labels/buttons fit at your display resolution. Drag the header; switch tabs. Escape and F8 close without opening the pause menu or leaving the mouse unlocked.
2. In a cave or at night, select Natural and Apply, then Clear / 60% and Apply. Compare brightness and check that color remains sensible. Try Soft / 35%, 0%, and 100%. Disable gamma and verify immediate return to normal lighting.
3. Change environment/time and walk in/out of a dungeon. Brightness should not accumulate. Log out and inspect the menu; no lighting boost should remain there.
4. Toggle custom mist off while gamma is enabled. Gamma should remain enabled. Shift+F8 should change only mist.
5. With mist visible, compare wisplight 5m vs 60m and torch 5m vs 60m. Disable custom mist settings to restore original captured ranges. Hide/restore mist; returning clouds may take a few seconds to fill in.
6. Join as an admin and as a regular player. Regular player controls must be read-only on both tabs. Admin Apply should update both clients. Join a third client afterward; it should receive the same values.
7. Have two admins open drafts, then apply from each: the stale second draft must be rejected/refreshed. Restart the server and confirm settings persisted.
8. Connect to a test server without this mod (or mismatched version): clients must retain vanilla visibility and have no editable overrides. Disconnect/reconnect to check session cleanup.

Send screenshots of F8 and the BepInEx LogOutput.log if appearance, loading, sync or lighting is incorrect.

Automated tests do not replace these live rendering/network checks.
