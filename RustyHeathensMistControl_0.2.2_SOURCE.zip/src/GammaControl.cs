// GPL-3.0. Ambient brightness behavior based on ColdSpirit0's ValheimGammaMod.
// Reworked by RustyLaserGaming, 2026-10-14, to hook Valheim's managed environment
// update instead of Unity's native getters/setters, and restore lighting safely.
using HarmonyLib;
using UnityEngine;

namespace RustyHeathensMistControl
{
    internal static class GammaControl
    {
        private static Color original, applied;
        private static bool captured, changed;

        internal static void CaptureEnvironment()
        {
            // SetEnv returns early without a camera. Never capture our prior boost then.
            if (Player.m_localPlayer == null || Utils.GetMainCamera() == null) { Restore(); return; }
            original = RenderSettings.ambientLight;
            captured = true;
            changed = false;
            Apply(Plugin.Instance == null ? MistSettings.Vanilla : Plugin.Instance.Effective);
        }

        private static void Apply(MistSettings settings)
        {
            Color color = original;
            if (settings.GammaEnabled)
                GammaMath.Brighten(ref color.r, ref color.g, ref color.b, settings.Brightness);
            applied = color;
            changed = !Same(color, original);
            RenderSettings.ambientLight = color;
        }

        internal static void Refresh(MistSettings settings)
        {
            if (!captured) return;
            if (Player.m_localPlayer == null) { Restore(); return; }
            // Don't overwrite newer lighting from another component between SetEnv calls.
            if (!Same(RenderSettings.ambientLight, changed ? applied : original))
            { captured = changed = false; return; }
            Apply(settings);
        }

        internal static void Restore()
        {
            if (captured && changed && Same(RenderSettings.ambientLight, applied))
                RenderSettings.ambientLight = original;
            captured = changed = false;
        }

        private static bool Same(Color a, Color b)
        { return Mathf.Approximately(a.r, b.r) && Mathf.Approximately(a.g, b.g) && Mathf.Approximately(a.b, b.b) && Mathf.Approximately(a.a, b.a); }

        [HarmonyPatch(typeof(EnvMan), "SetEnv")]
        private static class EnvironmentPatch
        {
            [HarmonyPriority(Priority.Last)]
            private static void Postfix() { CaptureEnvironment(); }
        }
    }
}
