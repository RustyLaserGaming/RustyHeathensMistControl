// Ambient color scaling adapted from ColdSpirit0/ValheimGammaMod (GPL-3.0).
// Modified by RustyLaserGaming, 2026-10-14: black/invalid input guards and RGB-only scaling.
using System;

namespace RustyHeathensMistControl
{
    internal static class GammaMath
    {
        internal static void Brighten(ref float r, ref float g, ref float b, int brightness)
        {
            if (brightness <= 0) return;
            float floor = Math.Min(100, brightness) / 100f;
            if (!Finite(r) || !Finite(g) || !Finite(b)) { r = g = b = floor; return; }
            r = Math.Max(0f, r); g = Math.Max(0f, g); b = Math.Max(0f, b);
            float average = r / 3f + g / 3f + b / 3f;
            if (average >= floor) return;
            // Pure black has no hue to preserve; avoid the original divide-by-zero.
            if (average <= 0.000001f) { r = g = b = floor; return; }
            float scale = floor / average;
            r *= scale; g *= scale; b *= scale;
        }
        private static bool Finite(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }
    }
}
