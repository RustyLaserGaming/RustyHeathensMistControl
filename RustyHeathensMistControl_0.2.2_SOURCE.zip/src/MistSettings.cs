using System;
using System.Globalization;

namespace RustyHeathensMistControl
{
    // Pure protocol and validation code: deliberately has no game dependencies.
    internal sealed class MistSettings
    {
        internal const int MinRadius = 5, MaxRadius = 60;
        internal readonly bool Enabled, RemoveMist, GammaEnabled;
        internal readonly int WispRadius, TorchRadius, Brightness;
        internal MistSettings(bool enabled, bool removeMist, int wisp, int torch, bool gamma = false, int brightness = 60)
        { Enabled = enabled; RemoveMist = removeMist; WispRadius = wisp; TorchRadius = torch; GammaEnabled = gamma; Brightness = brightness; }
        internal static MistSettings Defaults { get { return new MistSettings(true, false, 25, 30, true, 60); } }
        internal static MistSettings Vanilla { get { return new MistSettings(false, false, 25, 30); } }
        internal bool Valid { get { return WispRadius >= MinRadius && WispRadius <= MaxRadius && TorchRadius >= MinRadius && TorchRadius <= MaxRadius && Brightness >= 0 && Brightness <= 100; } }
        internal bool Same(MistSettings other)
        { return other != null && Enabled == other.Enabled && RemoveMist == other.RemoveMist && WispRadius == other.WispRadius && TorchRadius == other.TorchRadius && GammaEnabled == other.GammaEnabled && Brightness == other.Brightness; }
        internal string Wire()
        { return (Enabled ? "1" : "0") + "|" + (RemoveMist ? "1" : "0") + "|" + WispRadius.ToString(CultureInfo.InvariantCulture) + "|" + TorchRadius.ToString(CultureInfo.InvariantCulture) + "|" + (GammaEnabled ? "1" : "0") + "|" + Brightness.ToString(CultureInfo.InvariantCulture); }
        internal static bool TryRead(string[] parts, int offset, out MistSettings settings)
        {
            settings = null;
            bool enabled, remove, gamma; int wisp, torch, brightness;
            if (parts.Length < offset + 6 || !Bit(parts[offset], out enabled) || !Bit(parts[offset + 1], out remove) ||
                !Number(parts[offset + 2], out wisp) || !Number(parts[offset + 3], out torch) || !Bit(parts[offset + 4], out gamma) || !Number(parts[offset + 5], out brightness)) return false;
            var candidate = new MistSettings(enabled, remove, wisp, torch, gamma, brightness);
            if (!candidate.Valid) return false;
            settings = candidate; return true;
        }
        internal static bool Bit(string value, out bool result)
        { result = value == "1"; return result || value == "0"; }
        internal static bool Number(string value, out int result)
        { return int.TryParse(value, NumberStyles.None, CultureInfo.InvariantCulture, out result); }
        internal static int KindForName(string name)
        {
            if (name == null) return 0;
            if (name.EndsWith("(Clone)", StringComparison.Ordinal)) name = name.Substring(0, name.Length - 7);
            if (name == "demister_ball") return 1;
            if (name == "piece_groundtorch_mist") return 2;
            return 0;
        }
    }

    internal sealed class WireMessage
    {
        internal char Kind;
        internal int Revision, Notice;
        internal bool CanEdit;
        internal MistSettings Settings;
        internal static string Update(int revision, MistSettings value)
        { return "U|2|" + revision.ToString(CultureInfo.InvariantCulture) + "|" + value.Wire(); }
        internal static string State(int revision, bool canEdit, MistSettings value, int notice)
        { return "S|2|" + revision.ToString(CultureInfo.InvariantCulture) + "|" + (canEdit ? "1" : "0") + "|" + value.Wire() + "|" + notice.ToString(CultureInfo.InvariantCulture); }
        internal static bool TryParse(string text, out WireMessage message)
        {
            message = null;
            if (text == null || text.Length > 128) return false;
            string[] p = text.Split('|');
            if (p.Length < 2 || p[1] != "2") return false;
            var m = new WireMessage();
            if (p[0] == "H" && p.Length == 2) { m.Kind = 'H'; message = m; return true; }
            if (p.Length < 3 || !MistSettings.Number(p[2], out m.Revision)) return false;
            if (p[0] == "U" && p.Length == 9)
            { m.Kind = 'U'; if (!MistSettings.TryRead(p, 3, out m.Settings)) return false; }
            else if (p[0] == "S" && p.Length == 11)
            {
                m.Kind = 'S';
                if (!MistSettings.Bit(p[3], out m.CanEdit) || !MistSettings.TryRead(p, 4, out m.Settings) ||
                    !MistSettings.Number(p[10], out m.Notice) || m.Notice > 5) return false;
            }
            else return false;
            message = m; return true;
        }
        internal static int UpdateVerdict(bool admin, int currentRevision, WireMessage request)
        {
            if (!admin) return 2;
            if (request == null || request.Kind != 'U' || request.Settings == null || !request.Settings.Valid) return 4;
            return request.Revision == currentRevision ? 1 : 3;
        }
    }
}
