using System.Collections.Generic;
using UnityEngine;

namespace RustyHeathensMistControl
{
    internal static class RadiusControl
    {
        private sealed class Original
        {
            internal ParticleSystemForceField Field;
            internal float Start, End;
            internal int Kind;
        }
        private static readonly Dictionary<Demister, Original> originals = new Dictionary<Demister, Original>();

        internal static void Refresh(MistSettings settings)
        {
            // Use Valheim's active demister registry; no per-frame scene-wide search.
            foreach (Demister demister in Demister.GetDemisters())
            {
                if (demister == null) continue;
                Original original;
                if (!originals.TryGetValue(demister, out original))
                {
                    int kind = 0;
                    for (Transform t = demister.transform; t != null && kind == 0; t = t.parent)
                        kind = MistSettings.KindForName(t.name);
                    if (kind == 0) continue; // Leave Mistwalker, dvergr lamps and other fields alone.
                    ParticleSystemForceField field = demister.GetComponent<ParticleSystemForceField>();
                    if (field == null) continue;
                    original = new Original { Field = field, Start = field.startRange, End = field.endRange, Kind = kind };
                    originals.Add(demister, original);
                }
                Apply(original, settings);
            }
            foreach (Demister key in new List<Demister>(originals.Keys))
            {
                Original original = originals[key];
                if (key == null || original.Field == null) { originals.Remove(key); continue; }
                // Also restore inactive/pool objects so reused objects keep their original baseline.
                Apply(original, settings);
            }
        }
        private static void Apply(Original original, MistSettings settings)
        {
            float target = settings.Enabled ? (original.Kind == 1 ? settings.WispRadius : settings.TorchRadius) : original.End;
            float start = settings.Enabled && original.End > 0f ? original.Start * target / original.End : original.Start;
            if (!Mathf.Approximately(original.Field.endRange, target)) original.Field.endRange = target;
            if (!Mathf.Approximately(original.Field.startRange, start)) original.Field.startRange = start;
        }
        internal static void Restore()
        {
            foreach (Original original in originals.Values)
            {
                if (original.Field == null) continue;
                original.Field.startRange = original.Start; original.Field.endRange = original.End;
            }
            originals.Clear();
        }
    }
}
