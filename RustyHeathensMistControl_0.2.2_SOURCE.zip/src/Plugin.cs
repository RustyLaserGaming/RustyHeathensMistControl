using System;
using System.Collections.Generic;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;

namespace RustyHeathensMistControl
{
    [BepInPlugin(Id, "Rusty Heathens Mist Control", Version)]
    [BepInIncompatibility("ColdSpirit.GammaMod")]
    public sealed partial class Plugin : BaseUnityPlugin
    {
        public const string Id = "com.rustyheathens.mistcontrol", Version = "0.2.2";
        internal const string RpcName = "RHMC_Settings_v2";
        internal static Plugin Instance;
        private Harmony harmony;
        private ConfigEntry<bool> enabledSetting, removeMist, gammaEnabled;
        private ConfigEntry<int> wispRadius, torchRadius, brightness;
        private ConfigEntry<KeyboardShortcut> panelKey, toggleKey;
        private MistSettings localSettings, remoteSettings;
        private readonly HashSet<ZRpc> registered = new HashSet<ZRpc>();
        private readonly HashSet<ZRpc> subscribers = new HashSet<ZRpc>();
        private readonly Dictionary<ZRpc, float> requestTimes = new Dictionary<ZRpc, float>();
        private readonly Dictionary<ZRpc, float> helloTimes = new Dictionary<ZRpc, float>();
        private ZNet lastNet;
        private ZRpc serverRpc;
        private int revision, remoteRevision, helloAttempts;
        private float nextNetTick, nextHello, nextBroadcast, lastStateAt = -999f, pendingUntil;
        private bool remoteCanEdit;
        internal string Status = "";

        internal MistSettings Effective
        {
            get
            {
                if (ZNet.instance == null) return MistSettings.Vanilla;
                if (ZNet.instance.IsServer()) return localSettings ?? MistSettings.Vanilla;
                return RemoteFresh ? remoteSettings : MistSettings.Vanilla;
            }
        }
        internal bool RemoteFresh { get { return remoteSettings != null && Time.realtimeSinceStartup - lastStateAt < 20f; } }
        internal bool CanEdit
        {
            get { return ZNet.instance != null && (ZNet.instance.IsServer() || (RemoteFresh && remoteCanEdit)); }
        }
        internal bool Pending { get { return Time.realtimeSinceStartup < pendingUntil; } }
        internal int CurrentRevision { get { return ZNet.instance != null && ZNet.instance.IsServer() ? revision : remoteRevision; } }
        internal static bool HideMist { get { return Instance != null && Instance.Effective.Enabled && Instance.Effective.RemoveMist; } }

        private void Awake()
        {
            Instance = this;
            Config.SaveOnConfigSet = false;
            enabledSetting = Config.Bind("Server", "Enabled", true, "Enable custom mist settings. False restores captured vanilla ranges and mist rendering.");
            removeMist = Config.Bind("Server", "RemoveMist", false, "Hide Mistlands particle mist. Does not delete world objects or change weather fog.");
            var range = new AcceptableValueRange<int>(MistSettings.MinRadius, MistSettings.MaxRadius);
            wispRadius = Config.Bind("Server", "WisplightRadius", 25, new ConfigDescription("Equipped wisplight mist-clearing radius in meters.", range));
            torchRadius = Config.Bind("Server", "WispTorchRadius", 30, new ConfigDescription("Placed wisp torch mist-clearing radius in meters.", range));
            gammaEnabled = Config.Bind("Server", "GammaEnabled", true, "Brighten dark ambient lighting. Independent of the mist switch; controlled by the server.");
            brightness = Config.Bind("Server", "GammaBrightness", 60, new ConfigDescription("Minimum ambient brightness, 0-100. 60 matches the reference mod default; 0 leaves normal lighting. Does not change monitor gamma.", new AcceptableValueRange<int>(0, 100)));
            panelKey = Config.Bind("Controls", "PanelShortcut", new KeyboardShortcut(KeyCode.F8), "Local shortcut to open/close the in-game panel.");
            toggleKey = Config.Bind("Controls", "ToggleShortcut", new KeyboardShortcut(KeyCode.F8, KeyCode.LeftShift), "Local admin shortcut to toggle mist visibility.");
            localSettings = ReadLocal();
            Config.Save();
            harmony = new Harmony(Id);
            harmony.PatchAll(typeof(Plugin).Assembly);
            Logger.LogInfo("Rusty Heathens Mist Control " + Version + " loaded. F8: panel; Left Shift + F8: mist toggle.");
        }

        private MistSettings ReadLocal()
        { return new MistSettings(enabledSetting.Value, removeMist.Value, wispRadius.Value, torchRadius.Value, gammaEnabled.Value, brightness.Value); }

        private void Update()
        {
            if (!ReferenceEquals(lastNet, ZNet.instance)) ResetSession();
            float now = Time.realtimeSinceStartup;
            if (pendingUntil > 0f && now >= pendingUntil)
            { pendingUntil = 0f; Status = "No confirmation received. Check the current settings before trying again."; }
            if (now >= nextNetTick)
            {
                nextNetTick = now + 0.5f;
                NetworkTick(now);
                RadiusControl.Refresh(Effective);
                GammaControl.Refresh(Effective);
            }
            if (Player.m_localPlayer == null || Player.m_localPlayer.IsDead()) { ClosePanel(); return; }
            if (panelOpen)
            {
                if (Input.GetKeyDown(KeyCode.Escape)) { ClosePanel(); return; }
                if (panelKey.Value.IsDown()) { ClosePanel(); return; }
                return;
            }
            if (InputBlocked()) return;
            if (toggleKey.Value.IsDown())
            {
                if (!CanEdit) { Tell("Only a server admin can change mist settings."); return; }
                MistSettings s = Effective;
                Request(new MistSettings(true, !(s.Enabled && s.RemoveMist), s.WispRadius, s.TorchRadius, s.GammaEnabled, s.Brightness), CurrentRevision);
            }
            else if (panelKey.Value.IsDown()) OpenPanel();
        }

        private void ResetSession()
        {
            ClosePanel();
            foreach (ZRpc rpc in registered) rpc.Unregister(RpcName);
            registered.Clear(); subscribers.Clear(); requestTimes.Clear(); helloTimes.Clear();
            RadiusControl.Restore(); GammaControl.Restore();
            lastNet = ZNet.instance; serverRpc = null; remoteSettings = null; remoteCanEdit = false;
            revision = remoteRevision = helloAttempts = 0;
            lastStateAt = -999f; pendingUntil = nextHello = nextBroadcast = nextNetTick = 0f;
            Status = "";
        }

        internal void RegisterPeer(ZNetPeer peer)
        {
            if (!ReferenceEquals(lastNet, ZNet.instance)) ResetSession();
            if (peer == null || peer.m_rpc == null || !registered.Add(peer.m_rpc)) return;
            peer.m_rpc.Register<string>(RpcName, OnMessage);
        }

        private void NetworkTick(float now)
        {
            ZNet net = ZNet.instance;
            if (net == null) return;
            var live = new HashSet<ZRpc>();
            foreach (ZNetPeer peer in net.GetPeers())
            { RegisterPeer(peer); if (peer.m_rpc != null) live.Add(peer.m_rpc); }
            foreach (ZRpc rpc in new List<ZRpc>(registered))
            {
                if (live.Contains(rpc)) continue;
                rpc.Unregister(RpcName); registered.Remove(rpc); subscribers.Remove(rpc); requestTimes.Remove(rpc); helloTimes.Remove(rpc);
            }
            if (net.IsServer())
            {
                if (now >= nextBroadcast) { nextBroadcast = now + 5f; Broadcast(); }
                return;
            }
            ZNetPeer server = net.GetServerPeer();
            ZRpc rpcServer = server == null ? null : server.m_rpc;
            if (!ReferenceEquals(serverRpc, rpcServer))
            {
                serverRpc = rpcServer; remoteSettings = null; remoteCanEdit = false;
                helloAttempts = 0; nextHello = now; lastStateAt = -999f; pendingUntil = 0f;
            }
            if (serverRpc != null && now >= nextHello && (RemoteFresh || helloAttempts < 3))
            {
                serverRpc.Invoke(RpcName, "H|2"); helloAttempts++;
                nextHello = now + (RemoteFresh ? 10f : 3f);
            }
            if (!RemoteFresh && helloAttempts >= 3) Status = "No server sync. Install the same mod on the server, then reconnect.";
        }

        private static ZNetPeer PeerFor(ZNet net, ZRpc rpc)
        {
            foreach (ZNetPeer peer in net.GetPeers()) if (ReferenceEquals(peer.m_rpc, rpc)) return peer;
            return null;
        }
        // Authorization uses the authenticated transport, never a client-supplied player ID.
        private static bool IsAdmin(ZNet net, ZRpc rpc)
        { return rpc != null && rpc.GetSocket() != null && net.IsAdmin(rpc.GetSocket().GetHostName()); }

        private void OnMessage(ZRpc rpc, string payload)
        {
            ZNet net = ZNet.instance;
            if (net == null) return;
            ZNetPeer peer = PeerFor(net, rpc);
            if (peer == null || !peer.IsReady()) return;
            WireMessage message;
            if (!WireMessage.TryParse(payload, out message)) return;
            if (net.IsServer())
            {
                if (message.Kind != 'H' && message.Kind != 'U') return;
                float last; float now = Time.realtimeSinceStartup;
                Dictionary<ZRpc, float> rateTimes = message.Kind == 'H' ? helloTimes : requestTimes;
                if (rateTimes.TryGetValue(rpc, out last) && now - last < 0.2f) return;
                rateTimes[rpc] = now;
                subscribers.Add(rpc);
                if (message.Kind == 'H') { SendState(rpc, 0); return; }
                int verdict = WireMessage.UpdateVerdict(IsAdmin(net, rpc), revision, message);
                if (verdict == 1 && !Commit(message.Settings)) verdict = 5;
                if (verdict == 1)
                {
                    Logger.LogInfo("Visibility settings changed by authenticated server admin.");
                    Broadcast(rpc); SendState(rpc, 1);
                }
                else SendState(rpc, verdict);
                return;
            }
            ZNetPeer server = net.GetServerPeer();
            if (server == null || !ReferenceEquals(server.m_rpc, rpc) || message.Kind != 'S') return;
            if (RemoteFresh && message.Revision < remoteRevision) return;
            remoteSettings = message.Settings; remoteRevision = message.Revision;
            remoteCanEdit = message.CanEdit; lastStateAt = Time.realtimeSinceStartup;
            if (message.Notice != 0) pendingUntil = 0f;
            if (message.Notice == 1) { Status = "Applied to everyone using this mod."; RefreshDraft(); }
            else if (message.Notice == 2) Status = "Change refused: only server admins may change these settings.";
            else if (message.Notice == 3) { Status = "Another admin changed the settings. Review the refreshed values."; RefreshDraft(); }
            else if (message.Notice == 4) Status = "Invalid settings were rejected.";
            else if (message.Notice == 5) Status = "The server could not save its configuration. Change was not applied.";
            else if (Status.StartsWith("No server sync", StringComparison.Ordinal)) Status = "Server settings received.";
            if (panelOpen && !draftDirty) RefreshDraft();
            RadiusControl.Refresh(Effective);
                GammaControl.Refresh(Effective);
        }

        private void SendState(ZRpc rpc, int notice)
        {
            if (ZNet.instance == null || !ZNet.instance.IsServer() || !rpc.IsConnected()) return;
            rpc.Invoke(RpcName, WireMessage.State(revision, IsAdmin(ZNet.instance, rpc), localSettings, notice));
        }
        private void Broadcast(ZRpc except = null)
        {
            foreach (ZRpc rpc in new List<ZRpc>(subscribers))
                if (!ReferenceEquals(rpc, except)) SendState(rpc, 0);
        }

        private bool Commit(MistSettings settings)
        {
            if (settings == null || !settings.Valid) return false;
            MistSettings before = localSettings;
            SetEntries(settings);
            try { Config.Save(); }
            catch (Exception ex)
            {
                SetEntries(before); Logger.LogError("Could not save mist settings: " + ex.Message); return false;
            }
            if (!settings.Same(localSettings)) revision++;
            localSettings = settings;
            RadiusControl.Refresh(Effective);
                GammaControl.Refresh(Effective);
            RefreshDraft(); return true;
        }
        private void SetEntries(MistSettings settings)
        {
            enabledSetting.Value = settings.Enabled; removeMist.Value = settings.RemoveMist;
            wispRadius.Value = settings.WispRadius; torchRadius.Value = settings.TorchRadius;
            gammaEnabled.Value = settings.GammaEnabled; brightness.Value = settings.Brightness;
        }

        internal void Request(MistSettings settings, int expectedRevision)
        {
            if (!CanEdit || !settings.Valid || Pending) return;
            if (ZNet.instance.IsServer())
            {
                if (expectedRevision != revision) { Status = "Settings changed. Review the refreshed values."; RefreshDraft(); return; }
                if (Commit(settings)) { Broadcast(); Tell("Visibility settings applied."); Status = "Saved and applied."; }
                else Status = "Could not save configuration. Change was not applied.";
            }
            else if (serverRpc != null)
            {
                serverRpc.Invoke(RpcName, WireMessage.Update(expectedRevision, settings));
                pendingUntil = Time.realtimeSinceStartup + 3f;
                Status = "Requested. Waiting for server confirmation.";
            }
        }

        private static bool InputBlocked()
        {
            return (Chat.instance != null && Chat.instance.HasFocus()) || Console.IsVisible() || TextInput.IsVisible() ||
                Menu.IsVisible() || InventoryGui.IsVisible() || Minimap.IsOpen() || StoreGui.IsVisible();
        }
        private static void Tell(string text)
        { if (Player.m_localPlayer != null) Player.m_localPlayer.Message(MessageHud.MessageType.Center, text); }

        private void OnDestroy()
        {
            ClosePanel(); RadiusControl.Restore(); GammaControl.Restore();
            foreach (ZRpc rpc in registered) rpc.Unregister(RpcName);
            if (harmony != null) harmony.UnpatchSelf();
            DestroyPanelAssets();
            Instance = null;
        }

        [HarmonyPatch(typeof(ZNet), "OnNewConnection")]
        private static class ConnectionPatch
        {
            private static void Postfix(ZNetPeer __0) { if (Instance != null) Instance.RegisterPeer(__0); }
        }
        [HarmonyPatch(typeof(ParticleMist), "Update")]
        private static class MistPatch
        {
            private static bool Prefix(ParticleMist __instance)
            {
                if (!HideMist) return true;
                ParticleSystem ps = __instance.GetComponent<ParticleSystem>();
                if (ps != null && ps.particleCount > 0) ps.Clear(false);
                return false;
            }
        }
    }
}
