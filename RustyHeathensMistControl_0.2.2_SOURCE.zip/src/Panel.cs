using System.Collections.Generic;
using System.IO;
using HarmonyLib;
using UnityEngine;

namespace RustyHeathensMistControl
{
    public sealed partial class Plugin
    {
        private bool panelOpen, draftDirty, draftEnabled, draftRemove, draftGamma;
        private int draftWisp, draftTorch, draftBrightness, draftRevision, selectedTab, suppressThroughFrame = -1;
        private Rect panelRect = new Rect(40, 40, 560, 600);
        private GUISkin panelSkin;
        private GUIStyle headingStyle, mutedStyle, sectionStyle, selectedStyle;
        private readonly Dictionary<GUIStyle, GUIStyle> textOutlines = new Dictionary<GUIStyle, GUIStyle>();
        private readonly List<Texture2D> panelTextures = new List<Texture2D>();
        private Texture2D emblem;
        private CursorLockMode priorLock;
        private bool priorCursor;
        private static readonly Color Blue = new Color(0.12f, 0.67f, 1f);
        internal static bool BlockGameInput
        { get { return Instance != null && (Instance.panelOpen || Time.frameCount <= Instance.suppressThroughFrame); } }

        private void RefreshDraft()
        {
            MistSettings s = Effective;
            draftEnabled = s.Enabled; draftRemove = s.RemoveMist;
            draftWisp = s.WispRadius; draftTorch = s.TorchRadius;
            draftGamma = s.GammaEnabled; draftBrightness = s.Brightness;
            draftRevision = CurrentRevision; draftDirty = false;
        }
        private void OpenPanel()
        {
            FindInventoryWood(); RefreshDraft(); panelOpen = true; Status = "";
            priorLock = Cursor.lockState; priorCursor = Cursor.visible;
            if (ZNet.instance != null && !ZNet.instance.IsServer() && !RemoteFresh)
            { helloAttempts = 0; nextHello = 0f; Status = "Requesting server settings..."; }
            panelRect.x = Mathf.Max(12f, Screen.width * 0.5f / PanelScale - panelRect.width * 0.5f);
            panelRect.y = Mathf.Max(12f, Screen.height * 0.5f / PanelScale - panelRect.height * 0.5f);
        }
        private void ClosePanel()
        {
            if (!panelOpen) return;
            panelOpen = false; suppressThroughFrame = Time.frameCount + 1;
            Cursor.lockState = priorLock; Cursor.visible = priorCursor;
        }
        private float PanelScale { get { return Mathf.Clamp(Mathf.Min(Screen.width / 600f, Screen.height / 650f), 0.35f, 1.5f); } }
        private void LateUpdate()
        { if (panelOpen) { Cursor.lockState = CursorLockMode.None; Cursor.visible = true; } }

        // Small cached code-generated surfaces; no per-frame texture allocation.
        private Texture2D Surface(Color fill, Color border)
        {
            var texture = new Texture2D(16, 16, TextureFormat.RGBA32, false);
            texture.hideFlags = HideFlags.HideAndDontSave;
            for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++)
                texture.SetPixel(x, y, x == 0 || x == 15 || y == 0 || y == 15 ? border : fill);
            texture.Apply(false, true); panelTextures.Add(texture); return texture;
        }
        private static void Paint(GUIStyle style, Texture2D normal, Texture2D hover, Color text)
        {
            style.normal.background = normal; style.hover.background = hover; style.active.background = hover;
            style.focused.background = hover; style.onNormal.background = hover; style.onHover.background = hover;
            style.onActive.background = hover; style.onFocused.background = hover;
            style.normal.textColor = style.hover.textColor = style.active.textColor = style.focused.textColor = text;
            style.onNormal.textColor = style.onHover.textColor = style.onActive.textColor = style.onFocused.textColor = text;
            style.border = new RectOffset(2, 2, 2, 2);
        }
        private void CreatePanelSkin()
        {
            panelSkin = Instantiate(GUI.skin); panelSkin.hideFlags = HideFlags.HideAndDontSave;
            Color ink = new Color(0.16f, 0.095f, 0.05f), steel = new Color(0.26f, 0.16f, 0.085f);
            Color edge = new Color(0.38f, 0.26f, 0.14f), hover = new Color(0.30f, 0.22f, 0.13f);
            Texture2D frame = WoodSurface(ink, edge), button = WoodSurface(steel, edge), active = WoodSurface(hover, Blue);
            Paint(panelSkin.window, frame, frame, Color.white);
            panelSkin.window.padding = new RectOffset(22, 22, 20, 18);
            panelSkin.window.fontSize = 1;
            panelSkin.label.fontSize = 16; panelSkin.label.wordWrap = true; panelSkin.label.normal.textColor = Color.white;
            Paint(panelSkin.button, button, active, Color.white);
            panelSkin.button.fontSize = 16; panelSkin.button.fixedHeight = 36;
            panelSkin.button.margin = new RectOffset(3, 3, 4, 4);
            panelSkin.button.padding = new RectOffset(10, 10, 6, 6);
            panelSkin.toggle.fontSize = 16; panelSkin.toggle.wordWrap = true;
            panelSkin.toggle.normal.textColor = panelSkin.toggle.onNormal.textColor = Color.white;
            panelSkin.toggle.hover.textColor = panelSkin.toggle.onHover.textColor = Blue;
            Paint(panelSkin.horizontalSlider, Surface(steel, edge), Surface(steel, edge), Color.white);
            panelSkin.horizontalSlider.fixedHeight = 8;
            panelSkin.horizontalSlider.margin = new RectOffset(5, 5, 9, 13);
            Paint(panelSkin.horizontalSliderThumb, Surface(Blue, Blue), active, Color.white);
            panelSkin.horizontalSliderThumb.fixedWidth = 18; panelSkin.horizontalSliderThumb.fixedHeight = 22;
            panelSkin.horizontalSliderThumb.overflow = new RectOffset(0, 0, 7, 7);
            headingStyle = new GUIStyle(panelSkin.label); headingStyle.fontSize = 24; headingStyle.fontStyle = FontStyle.Bold; headingStyle.normal.textColor = new Color(0.68f, 0.89f, 1f);
            mutedStyle = new GUIStyle(panelSkin.label); mutedStyle.fontSize = 14; mutedStyle.normal.textColor = Color.white;
            sectionStyle = new GUIStyle(panelSkin.label); sectionStyle.fontSize = 17; sectionStyle.fontStyle = FontStyle.Bold; sectionStyle.normal.textColor = new Color(0.68f, 0.89f, 1f);
            selectedStyle = new GUIStyle(panelSkin.button); Paint(selectedStyle, active, active, Color.white);
            using (Stream stream = typeof(Plugin).Assembly.GetManifestResourceStream("RHMC.Emblem.png"))
            {
                if (stream != null)
                {
                    using (var memory = new MemoryStream())
                    {
                        stream.CopyTo(memory);
                        emblem = new Texture2D(2, 2); emblem.hideFlags = HideFlags.HideAndDontSave;
                        if (!ImageConversion.LoadImage(emblem, memory.ToArray(), true)) { Destroy(emblem); emblem = null; }
                    }
                }
            }
        }
        private void DestroyPanelAssets()
        {
            if (panelSkin != null) Destroy(panelSkin);
            if (emblem != null) Destroy(emblem);
            foreach (Texture2D texture in panelTextures) if (texture != null) Destroy(texture);
            panelTextures.Clear(); textOutlines.Clear();
        }
        private void OnGUI()
        {
            if (!panelOpen || Player.m_localPlayer == null) return;
            if (panelSkin == null) CreatePanelSkin();
            GUISkin oldSkin = GUI.skin; Matrix4x4 oldMatrix = GUI.matrix; int oldDepth = GUI.depth;
            try
            {
                GUI.skin = panelSkin; GUI.depth = -100;
                float scale = PanelScale;
                GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(scale, scale, 1f));
                panelRect.x = Mathf.Clamp(panelRect.x, 0f, Mathf.Max(0f, Screen.width / scale - panelRect.width));
                panelRect.y = Mathf.Clamp(panelRect.y, 0f, Mathf.Max(0f, Screen.height / scale - panelRect.height));
                panelRect = GUILayout.Window(19776301, panelRect, DrawPanel, "", GUILayout.Width(560), GUILayout.Height(600));
            }
            finally { GUI.skin = oldSkin; GUI.matrix = oldMatrix; GUI.depth = oldDepth; }
        }
        private void PanelLabel(string text, params GUILayoutOption[] options)
        { PanelLabel(text, panelSkin.label, options); }
        private void PanelLabel(string text, GUIStyle style, params GUILayoutOption[] options)
        {
            var content = new GUIContent(text);
            Rect rect = GUILayoutUtility.GetRect(content, style, options);
            if (Event.current.type != EventType.Repaint) return;
            GUIStyle outline;
            if (!textOutlines.TryGetValue(style, out outline))
            {
                outline = new GUIStyle(style);
                outline.normal.textColor = new Color(0.025f, 0.015f, 0.01f, 1f);
                textOutlines.Add(style, outline);
            }
            // Labels remain readable in the read-only admin panel as well.
            // Only label drawing is enabled here; interactive controls stay locked.
            bool enabled = GUI.enabled;
            try
            {
                GUI.enabled = true;
                GUI.Label(new Rect(rect.x - 1f, rect.y, rect.width, rect.height), content, outline);
                GUI.Label(new Rect(rect.x + 1f, rect.y, rect.width, rect.height), content, outline);
                GUI.Label(new Rect(rect.x, rect.y - 1f, rect.width, rect.height), content, outline);
                GUI.Label(new Rect(rect.x, rect.y + 1f, rect.width, rect.height), content, outline);
                GUI.Label(rect, content, style);
            }
            finally { GUI.enabled = enabled; }
        }
        private void DrawPanel(int id)
        {
            DrawInventoryWood(new Rect(0, 0, panelRect.width, panelRect.height));
            GUILayout.BeginHorizontal();
            if (emblem != null) GUILayout.Label(emblem, GUILayout.Width(86), GUILayout.Height(86));
            GUILayout.BeginVertical();
            GUILayout.Space(9); PanelLabel("RUSTY HEATHENS", headingStyle);
            PanelLabel("MIST CONTROL  /  GAMMA", sectionStyle);
            PanelLabel("Make the darkness answer to you.", mutedStyle);
            GUILayout.EndVertical(); GUILayout.EndHorizontal();
            bool host = ZNet.instance != null && ZNet.instance.IsServer();
            PanelLabel(host ? "HOST CONTROLS" : (CanEdit ? "SERVER ADMIN CONTROLS" : "SERVER SETTINGS  /  VIEW ONLY"), mutedStyle);
            GUILayout.Space(6);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Mist & wisps", selectedTab == 0 ? selectedStyle : panelSkin.button)) selectedTab = 0;
            if (GUILayout.Button("Gamma / brightness", selectedTab == 1 ? selectedStyle : panelSkin.button)) selectedTab = 1;
            GUILayout.EndHorizontal(); GUILayout.Space(12);
            bool oldEnabled = GUI.enabled;
            GUI.enabled = CanEdit && !Pending;
            if (selectedTab == 0) DrawMistSettings(); else DrawGammaSettings();
            GUI.enabled = oldEnabled;
            GUILayout.FlexibleSpace();
            PanelLabel(draftDirty ? "Unsaved changes - Apply saves both tabs for everyone." : "Settings are saved on the server and shared with players.", mutedStyle);
            GUI.enabled = CanEdit && !Pending;
            GUILayout.BeginHorizontal();
            if (GUILayout.Button(Pending ? "Applying..." : "Apply settings", selectedStyle))
                Request(new MistSettings(draftEnabled, draftRemove, draftWisp, draftTorch, draftGamma, draftBrightness), draftRevision);
            if (GUILayout.Button("Reset this tab"))
            {
                if (selectedTab == 0) { draftEnabled = true; draftRemove = false; draftWisp = 25; draftTorch = 30; }
                else { draftGamma = true; draftBrightness = 60; }
                draftDirty = true;
            }
            GUILayout.EndHorizontal(); GUI.enabled = oldEnabled;
            string detail = Status;
            if (!host && !RemoteFresh) detail = "Waiting for matching server version. Local overrides are disabled.";
            else if (!CanEdit && !host) detail = "Only server admins can apply changes.";
            PanelLabel(string.IsNullOrEmpty(detail) ? " " : detail, mutedStyle, GUILayout.Height(40));
            GUILayout.BeginHorizontal();
            PanelLabel(panelKey.Value + ": panel  |  " + toggleKey.Value + ": mist", mutedStyle);
            if (GUILayout.Button("Close", GUILayout.Width(85))) ClosePanel();
            GUILayout.EndHorizontal();
            GUI.DragWindow(new Rect(0, 0, 560, 108));
        }
        private void DrawMistSettings()
        {
            Toggle("Enable custom mist settings", ref draftEnabled);
            Toggle("Hide all Mistlands mist", ref draftRemove);
            GUILayout.Space(8);
            DrawSlider("Wisplight clearing radius", ref draftWisp, 5, 60, " m");
            DrawSlider("Wisp torch clearing radius", ref draftTorch, 5, 60, " m");
            PanelLabel(draftRemove && draftEnabled ? "Mist is hidden. Bring it back to see your clearing ranges." :
                (!draftEnabled ? "Original mist and clearing ranges will be restored." : "Adjust mist clearing without changing weather fog."), mutedStyle);
        }
        private void DrawGammaSettings()
        {
            Toggle("Enable gamma / brightness boost", ref draftGamma);
            GUILayout.Space(16);
            DrawSlider("Minimum ambient brightness", ref draftBrightness, 0, 100, "%");
            PanelLabel("Brighten dark nights and caves while keeping the lighting's color.", panelSkin.label);
            GUILayout.Space(12);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Natural")) { draftGamma = false; draftDirty = true; }
            if (GUILayout.Button("Soft  /  35%")) { draftGamma = true; draftBrightness = 35; draftDirty = true; }
            if (GUILayout.Button("Clear  /  60%")) { draftGamma = true; draftBrightness = 60; draftDirty = true; }
            GUILayout.EndHorizontal();
            GUILayout.Space(8);
            PanelLabel(draftGamma && draftBrightness > 0 ? "Only darker ambient lighting is raised. Higher values can flatten shadows." : "Normal game lighting will be restored.", mutedStyle);
            PanelLabel("Brightness works independently of the mist switch.", mutedStyle);
        }
        private void Toggle(string label, ref bool value)
        { bool next = GUILayout.Toggle(value, " " + label); if (next != value) { value = next; draftDirty = true; } }
        private void DrawSlider(string label, ref int value, int min, int max, string suffix)
        {
            PanelLabel(label + ": " + value + suffix);
            int next = Mathf.RoundToInt(GUILayout.HorizontalSlider(value, min, max));
            if (next != value) { value = next; draftDirty = true; }
        }

        [HarmonyPatch(typeof(Menu), "IsVisible")]
        private static class MenuVisiblePatch
        { private static void Postfix(ref bool __result) { if (BlockGameInput) __result = true; } }
        [HarmonyPatch(typeof(Menu), "IsActive")]
        private static class MenuActivePatch
        { private static void Postfix(ref bool __result) { if (BlockGameInput) __result = true; } }
        [HarmonyPatch(typeof(Menu), "Update")]
        private static class MenuUpdatePatch
        { private static bool Prefix() { return !BlockGameInput; } }
        [HarmonyPatch(typeof(PlayerController), "TakeInput")]
        private static class PlayerInputPatch
        {
            private static bool Prefix(ref bool __result)
            { if (!BlockGameInput) return true; __result = false; return false; }
        }
    }
}
