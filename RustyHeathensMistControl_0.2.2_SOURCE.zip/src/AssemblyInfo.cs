using System.Reflection;
[assembly: AssemblyTitle("Rusty Heathens Mist Control")]
[assembly: AssemblyDescription("Admin-synced Mistlands, wisp range and ambient brightness controls")]
[assembly: AssemblyCompany("RustyHeathens")]
[assembly: AssemblyVersion("0.2.2.0")]
[assembly: AssemblyFileVersion("0.2.2.0")]
