using UnityEngine;
using UnityEngine.UI;

namespace RustyHeathensMistControl
{
    public sealed partial class Plugin
    {
        private Sprite inventoryWood;
        private Color inventoryWoodTint = Color.white;

        private void FindInventoryWood()
        {
            inventoryWood = null;
            InventoryGui inventory = InventoryGui.instance;
            if (inventory == null || inventory.m_player == null) return;
            int best = 0;
            foreach (Image image in inventory.m_player.GetComponentsInChildren<Image>(true))
            {
                Sprite sprite = image.overrideSprite != null ? image.overrideSprite : image.sprite;
                if (sprite == null || sprite.texture == null) continue;
                string art = sprite.name.ToLowerInvariant(), name = image.name.ToLowerInvariant();
                int score = art.Contains("wood") ? 100 : 0;
                if (name == "bkg" || name == "background" || name == "bg") score += 30;
                if (image.type == Image.Type.Sliced) score += 10;
                // Require a background identity, never use an inventory item/icon.
                if (score < 30 || score <= best) continue;
                if (sprite.packed && sprite.packingRotation != SpritePackingRotation.None) continue;
                best = score; inventoryWood = sprite; inventoryWoodTint = image.color;
            }
            if (inventoryWood != null)
                Logger.LogDebug("F8 wood panel uses inventory sprite: " + inventoryWood.name);
        }

        private Texture2D WoodSurface(Color baseColor, Color edge)
        {
            var texture = new Texture2D(128, 128, TextureFormat.RGBA32, false);
            texture.hideFlags = HideFlags.HideAndDontSave;
            for (int y = 0; y < 128; y++) for (int x = 0; x < 128; x++)
            {
                float grain = 0.90f + 0.065f * Mathf.Sin(y * 2.2f + Mathf.Sin(x * 0.09f) * 0.7f)
                    + 0.03f * Mathf.Sin(y * 0.33f + x * 0.027f);
                Color color = baseColor * grain; color.a = 1f;
                if (x < 3 || y < 3 || x > 124 || y > 124) color = edge;
                else if (y % 32 == 0) color *= 0.6f;
                texture.SetPixel(x, y, color);
            }
            texture.Apply(false, true); panelTextures.Add(texture); return texture;
        }

        // Nine-slice the game's existing sprite directly from its atlas. No copied
        // game artwork is shipped, and the original inventory objects stay untouched.
        private void DrawInventoryWood(Rect target)
        {
            if (inventoryWood == null) return;
            Rect src;
            try { src = inventoryWood.textureRect; } catch { return; }
            Vector4 b = inventoryWood.border;
            float left = Mathf.Min(b.x, target.width / 3f), right = Mathf.Min(b.z, target.width / 3f);
            float bottom = Mathf.Min(b.y, target.height / 3f), top = Mathf.Min(b.w, target.height / 3f);
            float[] xs = { target.x, target.x + left, target.xMax - right, target.xMax };
            float[] ys = { target.y, target.y + top, target.yMax - bottom, target.yMax };
            float[] us = { src.x, src.x + b.x, src.xMax - b.z, src.xMax };
            float[] vs = { src.yMax, src.yMax - b.w, src.y + b.y, src.y };
            Texture2D atlas = inventoryWood.texture;
            Color before = GUI.color;
            GUI.color = new Color(inventoryWoodTint.r, inventoryWoodTint.g, inventoryWoodTint.b, 1f);
            for (int y = 0; y < 3; y++) for (int x = 0; x < 3; x++)
            {
                Rect dest = new Rect(xs[x], ys[y], xs[x + 1] - xs[x], ys[y + 1] - ys[y]);
                if (dest.width <= 0 || dest.height <= 0) continue;
                Rect uv = new Rect(us[x] / atlas.width, vs[y + 1] / atlas.height,
                    (us[x + 1] - us[x]) / atlas.width, (vs[y] - vs[y + 1]) / atlas.height);
                GUI.DrawTextureWithTexCoords(dest, atlas, uv, true);
            }
            GUI.color = before;
        }
    }
}
