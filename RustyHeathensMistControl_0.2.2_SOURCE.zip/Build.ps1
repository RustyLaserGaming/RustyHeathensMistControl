[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$GamePath,
    [string]$BepInExRoot
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$root = $PSScriptRoot
$managed = Join-Path $GamePath 'valheim_Data\Managed'
if (!(Test-Path $managed)) { $managed = Join-Path $GamePath 'valheim_server_Data\Managed' }
if (!$BepInExRoot) { $BepInExRoot = Join-Path $GamePath 'BepInEx' }
$core = Join-Path $BepInExRoot 'core'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path $compiler)) { $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
if (!(Test-Path $compiler)) { throw 'Windows .NET Framework C# compiler was not found.' }
$out = Join-Path $root 'build-output'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$dll = Join-Path $out 'RustyHeathensMistControl.dll'
$compilerArgs = @('/nologo','/noconfig','/nostdlib+','/target:library','/optimize+','/warn:4',('/out:'+$dll))
$gameRefs = @('mscorlib','netstandard','System','System.Core','UnityEngine','UnityEngine.CoreModule','UnityEngine.IMGUIModule','UnityEngine.ParticleSystemModule','UnityEngine.InputLegacyModule','UnityEngine.TextRenderingModule','UnityEngine.ImageConversionModule','UnityEngine.UI','assembly_valheim','assembly_utils','Splatform','SoftReferenceableAssets')
foreach ($name in $gameRefs) {
    $path = Join-Path $managed ($name+'.dll')
    if (!(Test-Path $path)) { throw "Missing game reference: $path" }
    $compilerArgs += '/reference:'+$path
}
foreach ($name in @('BepInEx','0Harmony')) {
    $path = Join-Path $core ($name+'.dll')
    if (!(Test-Path $path)) { throw "Missing BepInEx reference: $path" }
    $compilerArgs += '/reference:'+$path
}
$compilerArgs += '/resource:'+(Join-Path $root 'assets\Emblem.png')+',RHMC.Emblem.png'
$compilerArgs += @(Get-ChildItem (Join-Path $root 'src') -Filter '*.cs' | Sort-Object Name | ForEach-Object { $_.FullName })
& $compiler @compilerArgs 2>&1 | Tee-Object -FilePath (Join-Path $out 'compiler.log')
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed. See compiler.log.' }
$logic = Join-Path $out 'LogicTests.exe'
& $compiler /nologo /target:exe ('/out:'+$logic) (Join-Path $root 'src\MistSettings.cs') (Join-Path $root 'tests\Program.cs')
if ($LASTEXITCODE -ne 0) { throw 'Logic test compilation failed.' }
& $logic
if ($LASTEXITCODE -ne 0) { throw 'Logic tests failed.' }
$radii = Join-Path $out 'RadiusTests.exe'
& $compiler /nologo /target:exe ('/out:'+$radii) (Join-Path $root 'src\MistSettings.cs') (Join-Path $root 'src\RadiusControl.cs') (Join-Path $root 'tests\UnityStubs.cs') (Join-Path $root 'tests\RadiusTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Radius test compilation failed.' }
& $radii
if ($LASTEXITCODE -ne 0) { throw 'Radius tests failed.' }
$gamma = Join-Path $out 'GammaTests.exe'
& $compiler /nologo /target:exe ('/out:'+$gamma) (Join-Path $root 'src\MistSettings.cs') (Join-Path $root 'src\GammaMath.cs') (Join-Path $root 'src\GammaControl.cs') (Join-Path $root 'tests\GammaStubs.cs') (Join-Path $root 'tests\GammaTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Gamma test compilation failed.' }
& $gamma
if ($LASTEXITCODE -ne 0) { throw 'Gamma tests failed.' }
Write-Host "Built: $dll"
Write-Host 'Nothing was installed. A live Valheim test is still required.'
