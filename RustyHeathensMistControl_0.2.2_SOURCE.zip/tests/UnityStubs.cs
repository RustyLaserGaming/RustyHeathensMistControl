// Minimal test doubles used only by the standalone radius tests, never by the mod DLL.
using System;
using System.Collections.Generic;
namespace UnityEngine
{
    public class Transform { public string name; public Transform parent; }
    public class ParticleSystemForceField { public float startRange, endRange; }
    public static class Mathf
    { public static bool Approximately(float a, float b) { return Math.Abs(a-b) < 0.00001f; } }
}
public class Demister
{
    public UnityEngine.Transform transform;
    public UnityEngine.ParticleSystemForceField field;
    public T GetComponent<T>() where T : class { return field as T; }
    public static readonly List<Demister> Active = new List<Demister>();
    public static List<Demister> GetDemisters() { return Active; }
}
