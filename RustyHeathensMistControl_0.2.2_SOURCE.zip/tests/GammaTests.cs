using System;
using UnityEngine;
using RustyHeathensMistControl;
internal class GammaTests
{
    static int checks;
    static void Check(bool condition, string name) { if (!condition) throw new Exception(name); checks++; }
    static bool Near(float a, float b) { return Math.Abs(a-b) < 0.00001f; }
    static void ColorIs(float r, float g, float b, float a, string name)
    {
        Color c = RenderSettings.ambientLight;
        Check(Near(c.r, r) && Near(c.g, g) && Near(c.b, b) && Near(c.a, a), name);
    }
    static void Main()
    {
        Player.m_localPlayer = new Player(); Plugin.Instance = new Plugin();
        RenderSettings.ambientLight = new Color(.1f, .2f, .3f, .7f);
        GammaControl.CaptureEnvironment(); ColorIs(.3f, .6f, .9f, .7f, "hue and alpha preserved");
        for (int i=0; i<100; i++) GammaControl.Refresh(MistSettings.Defaults);
        ColorIs(.3f, .6f, .9f, .7f, "no repeated boost feedback");
        GammaControl.Refresh(MistSettings.Vanilla); ColorIs(.1f,.2f,.3f,.7f,"disable or sync loss restores");
        GammaControl.Refresh(MistSettings.Defaults); ColorIs(.3f,.6f,.9f,.7f,"reenable without recapture");
        GammaControl.Refresh(new MistSettings(false, false, 25, 30, true, 35));
        ColorIs(.175f,.35f,.525f,.7f,"gamma independent of mist enable");
        GammaControl.Restore(); ColorIs(.1f,.2f,.3f,.7f,"unload restore");
        RenderSettings.ambientLight = new Color(0,0,0,.4f);
        GammaControl.CaptureEnvironment(); ColorIs(.6f,.6f,.6f,.4f,"black stays finite");
        RenderSettings.ambientLight = new Color(.2f,.3f,.4f);
        GammaControl.CaptureEnvironment(); ColorIs(.4f,.6f,.8f,1,"new environment baseline");
        RenderSettings.ambientLight = new Color(.8f,.9f,1f);
        GammaControl.CaptureEnvironment(); ColorIs(.8f,.9f,1f,1,"bright daylight unchanged");
        RenderSettings.ambientLight = new Color(.1f,.1f,.1f);
        GammaControl.CaptureEnvironment();
        RenderSettings.ambientLight = new Color(.8f,.7f,.6f);
        GammaControl.Restore(); ColorIs(.8f,.7f,.6f,1,"external lighting not overwritten");
        RenderSettings.ambientLight = new Color(.1f,.1f,.1f);
        GammaControl.CaptureEnvironment(); Player.m_localPlayer = null;
        GammaControl.Refresh(MistSettings.Defaults); ColorIs(.1f,.1f,.1f,1,"logout restores");
        GammaControl.CaptureEnvironment(); ColorIs(.1f,.1f,.1f,1,"headless/menu no boost");
        Player.m_localPlayer = new Player(); Utils.Camera = null;
        GammaControl.CaptureEnvironment(); ColorIs(.1f,.1f,.1f,1,"no camera no capture");
        Utils.Camera = new object();
        GammaControl.CaptureEnvironment();
        GammaControl.Refresh(new MistSettings(true, false, 25, 30, true, 0)); ColorIs(.1f,.1f,.1f,1,"zero is natural");
        float r=float.NaN,g=0,b=0; GammaMath.Brighten(ref r,ref g,ref b,60);
        Check(Near(r,.6f) && Near(g,.6f) && Near(b,.6f),"invalid input sanitized");
        Console.WriteLine("PASS: " + checks + " brightness, hue/alpha, feedback, environment and restoration checks (test doubles, not Unity rendering).");
    }
}
