using System;
using UnityEngine;
using RustyHeathensMistControl;
internal static class RadiusTests
{
    private static int checks;
    private static void Check(bool valid, string label)
    { if (!valid) throw new Exception("FAILED: " + label); checks++; }
    private static Demister Add(string name, float start, float end)
    {
        var d = new Demister { transform = new Transform { name = name }, field = new ParticleSystemForceField { startRange = start, endRange = end } };
        Demister.Active.Add(d); return d;
    }
    private static void Main()
    {
        var wisp = Add("demister_ball(Clone)", 2f, 10f);
        var torch = Add("Particle System Force Field", 3f, 12f);
        torch.transform.parent = new Transform { name = "piece_groundtorch_mist(Clone)" };
        var other = Add("SwordMistwalker", 1f, 5f);
        RadiusControl.Refresh(MistSettings.Defaults);
        Check(wisp.field.endRange == 25f && wisp.field.startRange == 5f, "wisp target and proportional inner radius");
        Check(torch.field.endRange == 30f && torch.field.startRange == 7.5f, "torch classified through parent");
        Check(other.field.endRange == 5f && other.field.startRange == 1f, "Mistwalker unaffected");
        for (int i=0; i<20; i++) RadiusControl.Refresh(MistSettings.Defaults);
        Check(wisp.field.endRange == 25f && wisp.field.startRange == 5f, "repeated refresh does not multiply range");
        RadiusControl.Refresh(new MistSettings(true, false, 60, 5));
        Check(wisp.field.endRange == 60f && wisp.field.startRange == 12f, "live increase");
        Check(torch.field.endRange == 5f && torch.field.startRange == 1.25f, "live decrease");
        var newWisp = Add("demister_ball", 0f, 10f);
        RadiusControl.Refresh(MistSettings.Defaults);
        Check(newWisp.field.endRange == 25f && newWisp.field.startRange == 0f, "newly loaded wisp updated");
        Demister.Active.Remove(torch);
        RadiusControl.Refresh(MistSettings.Vanilla);
        Check(torch.field.endRange == 12f && torch.field.startRange == 3f, "inactive pooled torch restored");
        Check(wisp.field.endRange == 10f && wisp.field.startRange == 2f, "disable restores original wisp");
        Check(newWisp.field.endRange == 10f, "disable restores new wisp");
        RadiusControl.Refresh(MistSettings.Defaults);
        RadiusControl.Restore();
        Check(wisp.field.endRange == 10f && torch.field.endRange == 12f, "session cleanup restores original radii");
        RadiusControl.Refresh(MistSettings.Defaults);
        RadiusControl.Restore();
        Check(wisp.field.endRange == 10f, "new session captures original baseline");
        Console.WriteLine("PASS: " + checks + " range application and restoration checks using Unity test doubles.");
        Console.WriteLine("Real particle rendering and Unity object lifecycle require in-game testing.");
    }
}
