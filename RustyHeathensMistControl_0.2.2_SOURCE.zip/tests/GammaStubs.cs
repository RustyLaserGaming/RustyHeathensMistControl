// Standalone test doubles; never included in the shipped DLL.
using System;
namespace HarmonyLib
{
    public class HarmonyPatch : Attribute { public HarmonyPatch(Type t, string name) {} }
    public class HarmonyPriority : Attribute { public HarmonyPriority(int value) {} }
    public static class Priority { public const int Last = 0; }
}
namespace UnityEngine
{
    public struct Color
    {
        public float r, g, b, a;
        public Color(float red, float green, float blue, float alpha = 1f) { r = red; g = green; b = blue; a = alpha; }
    }
    public static class RenderSettings { public static Color ambientLight; }
    public static class Mathf { public static bool Approximately(float a, float b) { return Math.Abs(a - b) < 0.00001f; } }
}
public class EnvMan {}
public class Player { public static Player m_localPlayer; }
public static class Utils { public static object Camera = new object(); public static object GetMainCamera() { return Camera; } }
namespace RustyHeathensMistControl
{
    public class Plugin
    {
        public static Plugin Instance;
        internal MistSettings Effective = MistSettings.Defaults;
    }
}
