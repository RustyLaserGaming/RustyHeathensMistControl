using System;
using System.Globalization;
using RustyHeathensMistControl;
internal static class Program
{
    private static int checks;
    private static void Check(bool condition, string name)
    { if (!condition) throw new Exception("FAILED: " + name); checks++; }
    private static WireMessage Parse(string text)
    { WireMessage m; Check(WireMessage.TryParse(text, out m), "valid packet: " + text); return m; }
    private static void Main()
    {
        Check(MistSettings.Defaults.Valid && MistSettings.Defaults.GammaEnabled && MistSettings.Defaults.Brightness == 60, "defaults");
        Check(!MistSettings.Vanilla.Enabled && !MistSettings.Vanilla.GammaEnabled, "unsynced client restores both features");
        foreach (int radius in new[] { 5, 25, 30, 60 })
        foreach (bool enabled in new[] { false, true })
        foreach (bool remove in new[] { false, true })
        foreach (bool gamma in new[] { false, true })
        foreach (int brightness in new[] { 0, 35, 60, 100 })
        {
            var settings = new MistSettings(enabled, remove, radius, 65 - radius, gamma, brightness);
            var update = Parse(WireMessage.Update(3, settings));
            Check(update.Settings.Same(settings) && update.Revision == 3, "update roundtrip");
            for (int notice = 0; notice <= 5; notice++)
            {
                var state = Parse(WireMessage.State(3, enabled, settings, notice));
                Check(state.Settings.Same(settings) && state.Notice == notice && state.CanEdit == enabled, "state roundtrip");
            }
        }
        Check(Parse("H|2").Kind == 'H', "handshake");
        foreach (string invalid in new[] { null, "", "H|1", "H|2|extra", "S|2", "U|2", "U|1|0|1|0|25|30", "U|2|-1|1|0|25|30|1|60", "U|2|0|true|0|25|30|1|60", "U|2|0|1|0|4|30|1|60", "U|2|0|1|0|61|30|1|60", "U|2|0|1|0|25|0|1|60", "U|2|0|1|0|NaN|30|1|60", "U|2|0|1|0|Infinity|30|1|60", "U|2|0|1|0|25.5|30|1|60", "U|2|0|1|0|25|30|1|60|extra", "U|2|2147483648|1|0|25|30|1|60", "S|2|0|2|1|0|25|30|1|60|0", "S|2|0|1|1|0|25|30|1|60|6", "S|2|0|1|1|0|25|30|1|60|-1", "U|2|0|1|0|25|30|2|60", "U|2|0|1|0|25|30|1|101", "U|2|0|1|0|25|30|1|-1", "U|2|0|1|0|25|30|1|NaN", "U|2|0|1|0|25|30|1|60.5", "U|2|0|1|0|25|30", new string('X', 129) })
        { WireMessage m; Check(!WireMessage.TryParse(invalid, out m), "invalid request rejected: " + invalid); }
        WireMessage valid = Parse("U|2|7|1|1|25|30|1|60");
        Check(WireMessage.UpdateVerdict(false, 7, valid) == 2, "nonadmin denied");
        Check(WireMessage.UpdateVerdict(false, 8, valid) == 2, "nonadmin stale request denied");
        Check(WireMessage.UpdateVerdict(true, 8, valid) == 3, "stale admin prevented from overwriting");
        Check(WireMessage.UpdateVerdict(true, 7, valid) == 1, "current admin allowed");
        Check(WireMessage.UpdateVerdict(true, 7, null) == 4, "null update rejected");
        Check(WireMessage.UpdateVerdict(true, 7, Parse("H|2")) == 4, "hello cannot apply settings");
        Check(WireMessage.UpdateVerdict(true, 7, Parse("S|2|7|1|1|0|25|30|1|60|0")) == 4, "state cannot apply settings");
        Check(!MistSettings.Defaults.Same(new MistSettings(true, false, 25, 30, false, 60)), "gamma toggle increments revision");
        Check(!MistSettings.Defaults.Same(new MistSettings(true, false, 25, 30, true, 35)), "brightness increments revision");
        Check(MistSettings.KindForName("demister_ball(Clone)") == 1, "wisplight classification");
        Check(MistSettings.KindForName("piece_groundtorch_mist") == 2, "torch classification");
        foreach (string other in new[] { null, "", "SwordMistwalker", "dverger_demister", "demister_ball_fake", "fire_pit" })
            Check(MistSettings.KindForName(other) == 0, "unrelated emitters untouched");
        CultureInfo.CurrentCulture = new CultureInfo("fr-FR");
        Check(Parse(WireMessage.Update(7, MistSettings.Defaults)).Settings.Same(MistSettings.Defaults), "locale-independent protocol");
        Console.WriteLine("PASS: " + checks + " protocol, authorization-decision, validation and classification checks.");
    }
}
